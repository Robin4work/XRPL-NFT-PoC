from fastapi import FastAPI
from app.routes.nft import router as nft_router

app = FastAPI(title="Gemstone NFT API")

app.include_router(nft_router)


@app.get("/")
def root():
    return {"message": "Gemstone NFT API Running 🚀"}